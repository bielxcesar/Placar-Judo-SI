// 🎯 Inicialização do placar e penalidades
setPlacar(getPlacar());
const penalidadesIniciais = getPenalidades();
for (const time in penalidadesIniciais) {
  const select = document.getElementById(`penalidade${time}`);
  if (select) select.value = penalidadesIniciais[time];
}

// 🥋 Funções de placar
function getPlacar() {
  return JSON.parse(localStorage.getItem('placar')) || {
    ipponA: 0, wazariA: 0, yukoA: 0, shidoA: 0,
    ipponB: 0, wazariB: 0, yukoB: 0, shidoB: 0
  };
}

function setPlacar(placar) {
  localStorage.setItem('placar', JSON.stringify(placar));
}

function increment(tipo, lado) {
  const placar = getPlacar();
  placar[`${tipo}${lado}`]++;
  setPlacar(placar);
  atualizarPlacar();

  if (tipo === 'ippon') {
    localStorage.setItem('ipponTrigger', Date.now()); // sinaliza ippon
  }
}


function decrement(tipo, lado) {
  const placar = getPlacar();
  placar[`${tipo}${lado}`] = Math.max(0, placar[`${tipo}${lado}`] - 1);
  setPlacar(placar);
  atualizarPlacar();
}

// 🟨 Cartões Shido
function atualizarCartoesShido(qtd, lado) {
  const container = document.getElementById(`cartoes-shido${lado}`);
  if (!container) return;
  container.innerHTML = '';
  for (let i = 0; i < Math.min(qtd, 3); i++) {
    const cartao = document.createElement('div');
    cartao.classList.add('cartao');
    container.appendChild(cartao);
  }
}

// ⏱️ Tempo
let minutos = 0;
let segundos = 0;
let tempoSubindo = false;
let timerInterval;

function atualizarDisplay() {
  const m = String(minutos).padStart(2, '0');
  const s = String(segundos).padStart(2, '0');
  const prefixo = tempoSubindo ? '+' : '';
  document.getElementById('tempo').textContent = `${prefixo}${m}:${s}`;
  localStorage.setItem('tempo', JSON.stringify({ minutos, segundos, golden: tempoSubindo }));
}

function iniciarTimer() {
  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    if (houveIppon()) {
      pausarTimer();
      mostrarVideoIppon();
      return;
    }

    const goldenAtivo = document.getElementById('goldenScore')?.checked;

    if (!tempoSubindo) {
      if (minutos === 0 && segundos === 0) {
        if (goldenAtivo) {
          localStorage.setItem('goldenScoreTrigger', Date.now()); // sinaliza golden score
          tempoSubindo = true;
          segundos = 1;
        } else {
          clearInterval(timerInterval);
          return;
        }
      } else {
        if (segundos === 0) {
          segundos = 59;
          minutos--;
        } else {
          segundos--;
        }
      }
    } else {
      segundos++;
      if (segundos === 60) {
        segundos = 0;
        minutos++;
      }
    }

    atualizarDisplay();
  }, 1000);
}

function pausarTimer() {
  clearInterval(timerInterval);
}

function resetarTimer() {
  clearInterval(timerInterval);
  minutos = 0;
  segundos = 0;
  tempoSubindo = false;
  atualizarDisplay();
  resetarSaikomi();
}

function aumentarTempo() {
  minutos++;
  atualizarDisplay();
}

function diminuirTempo() {
  if (minutos > 0) minutos--;
  atualizarDisplay();
}

function setarQuatroMinutos() {
  minutos = 4;
  segundos = 0;
  tempoSubindo = false;
  atualizarDisplay();
}

// 🕒 Saikomi
let intervaloSaikomi;

function iniciarSaikomi(time) {
  clearInterval(intervaloSaikomi);
  let segundos = 0;
  intervaloSaikomi = setInterval(() => {
    segundos++;
    localStorage.setItem('saikomi', JSON.stringify({ time, segundos }));
    document.getElementById('saikomiTimer').textContent = `Saikomi: ${segundos}s`;
    if (segundos >= 20) clearInterval(intervaloSaikomi);
  }, 1000);
}

function resetarSaikomi() {
  clearInterval(intervaloSaikomi);
  localStorage.removeItem('saikomi');
  document.getElementById('saikomiTimer').textContent = 'Saikomi: 00s';
}

// 🎥 Vídeo de Ippon
function exibirVideoIppon() {
  const video = document.getElementById('ipponVideo');
  if (video && !videoEmExecucao) {
    videoEmExecucao = true;

    // Pausa e reinicia o vídeo com segurança
    video.pause();
    video.currentTime = 0;

    // Aguarda o vídeo estar pronto para reprodução
    video.oncanplay = () => {
      video.style.display = 'block';
      video.play();
    };

    // Garante que o vídeo seja exibido mesmo se já estiver pronto
    if (video.readyState >= 2) {
      video.style.display = 'block';
      video.play();
    }

    // Oculta o vídeo após 8 segundos
    setTimeout(() => {
      video.pause();
      video.style.display = 'none';
      videoEmExecucao = false;
    }, 8000);
  }
}
function exibirVideoGoldenScore() {
  const video = document.getElementById('goldenScoreVideo');
  if (video && !videoEmExecucao) {
    videoEmExecucao = true;
    pausarTimer();

    video.pause();
    video.currentTime = 0;

    video.oncanplay = () => {
      video.style.display = 'block';
      video.play();
    };

    if (video.readyState >= 2) {
      video.style.display = 'block';
      video.play();
    }

    setTimeout(() => {
      video.pause();
      video.style.display = 'none';
      videoEmExecucao = false;
    }, 8000);
  }
}

function houveIppon() {
  const placar = getPlacar();
  return placar.ipponA > 0 || placar.ipponB > 0;
}

// 🔄 Atualizações periódicas
function atualizarPlacar() {
  const placar = getPlacar();
  for (const tipo of ['ippon', 'wazari', 'yuko', 'shido']) {
    for (const lado of ['A', 'B']) {
      const id = `${tipo}${lado}`;
      const el = document.getElementById(id);
      if (el) el.textContent = placar[id];
      if (tipo === 'shido') atualizarCartoesShido(placar[id], lado);
    }
  }
} // ← esta chave estava faltando

function atualizarPenalidades() {
  const penalidades = getPenalidades();
  for (const time of ['A', 'B']) {
    const el = document.getElementById(`shido${time}`);
    if (el) el.textContent = penalidades[time];
  }
}

function getPenalidades() {
  return JSON.parse(localStorage.getItem('penalidades')) || { A: 0, B: 0 };
}

function setPenalidades(penalidades) {
  localStorage.setItem('penalidades', JSON.stringify(penalidades));
}

function atualizarPenalidade(time) {
  const select = document.getElementById(`penalidade${time}`);
  const penalidades = getPenalidades();
  penalidades[time] = parseInt(select.value);
  setPenalidades(penalidades);
}

function atualizarSaikomi() {
  const saikomi = JSON.parse(localStorage.getItem('saikomi'));
  const barraAzul = document.getElementById('barraAzul');
  const barraBranco = document.getElementById('barraBranco');

  if (!saikomi || saikomi.time === null) {
    if (barraAzul) barraAzul.style.width = '0%';
    if (barraBranco) barraBranco.style.width = '0%';
    return;
  }

  const { time, segundos } = saikomi;
  const progresso = Math.min((segundos / 20) * 100, 100);

  const barra = time === 'azul' ? barraAzul : barraBranco;
  const outraBarra = time === 'azul' ? barraBranco : barraAzul;

  if (barra) barra.style.width = `${progresso}%`;
  if (outraBarra) outraBarra.style.width = '0%';
}
function toggleDestaque(lado) {
  const checkbox = document.getElementById(`destaque${lado.charAt(0).toUpperCase() + lado.slice(1)}`);
  const bloco = document.querySelector(`.controle-time.${lado}`);

  if (checkbox.checked) {
    bloco.classList.add('destaque-vermelho');
  } else {
    bloco.classList.remove('destaque-vermelho');
  }
}


// 🌗 Tema claro/escuro
const body = document.body;
const toggleBtn = document.getElementById('toggleTheme');

function aplicarTema(tema) {
  if (tema === 'escuro') {
    body.classList.add('dark-mode');
    toggleBtn.textContent = '🌞 Modo Claro';
  } else {
    body.classList.remove('dark-mode');
    toggleBtn.textContent = '🌚 Modo Escuro';
  }
  localStorage.setItem('tema', tema);
}

const temaSalvo = localStorage.getItem('tema') || 'claro';
aplicarTema(temaSalvo);

toggleBtn.addEventListener('click', () => {
  const novoTema = body.classList.contains('dark-mode') ? 'claro' : 'escuro';
  aplicarTema(novoTema);
});

// ⏱️ Atualizações contínuas
setInterval(() => {
  atualizarPlacar();
  atualizarDisplay();
  atualizarPenalidades();
  atualizarSaikomi();
}, 1000);
