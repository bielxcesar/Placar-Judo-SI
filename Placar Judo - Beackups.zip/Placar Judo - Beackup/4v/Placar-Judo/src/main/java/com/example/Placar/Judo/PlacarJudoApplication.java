package com.example.Placar.Judo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacarJudoApplication {
    public static void main(String[] args) {
        SpringApplication.run(PlacarJudoApplication.class, args);
    }
}
