package com.example.Placar.Judo;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/placar")
public class PlacarRestController {

    private int scoreA = 0;
    private int scoreB = 0;

    @GetMapping
    public Map<String, Integer> getPlacar() {
        return Map.of("timeA", scoreA, "timeB", scoreB);
    }

    @PostMapping("/increment")
    public void increment(@RequestParam String team) {
        if ("A".equals(team)) scoreA++;
        else if ("B".equals(team)) scoreB++;
    }

    @PostMapping("/decrement")
    public void decrement(@RequestParam String team) {
        if ("A".equals(team) && scoreA > 0) scoreA--;
        else if ("B".equals(team) && scoreB > 0) scoreB--;
    }
}