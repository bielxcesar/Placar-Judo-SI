function getPlacar() {
  return JSON.parse(localStorage.getItem('placar')) || { timeA: 0, timeB: 0 };
}

function setPlacar(placar) {
  localStorage.setItem('placar', JSON.stringify(placar));
  document.getElementById('scoreA').textContent = placar.timeA;
  document.getElementById('scoreB').textContent = placar.timeB;
}

function increment(time) {
  const placar = getPlacar();
  if (time === 'A') placar.timeA++;
  else placar.timeB++;
  setPlacar(placar);
}

function decrement(time) {
  const placar = getPlacar();
  if (time === 'A') placar.timeA = Math.max(0, placar.timeA - 1);
  else placar.timeB = Math.max(0, placar.timeB - 1);
  setPlacar(placar);
}

// Inicializa os valores na tela
setPlacar(getPlacar());

let minutos = 0;
let segundos = 0;
let intervalo = null;

// Recupera o tempo salvo no localStorage
function salvarTempo() {
  localStorage.setItem('tempo', JSON.stringify({ minutos, segundos }));
}

function atualizarDisplay() {
  const m = String(minutos).padStart(2, '0');
  const s = String(segundos).padStart(2, '0');
  document.getElementById('tempo').textContent = `${m}:${s}`;
  salvarTempo();

}

function iniciarTimer() {
  if (intervalo) return; // já está rodando
  intervalo = setInterval(() => {
    if (segundos === 0 && minutos === 0) {
      pausarTimer();
      return;
    }
    if (segundos === 0) {
      minutos--;
      segundos = 59;
    } else {
      segundos--;
    }
    atualizarDisplay();
  }, 1000);
  salvarTempo();
}

function pausarTimer() {
  clearInterval(intervalo);
  intervalo = null;
  salvarTempo();

}


function resetarTimer() {
  pausarTimer();
  minutos = 0;
  segundos = 0;
  atualizarDisplay();
  salvarTempo();
}

function aumentarTempo() {
  minutos++;
  atualizarDisplay();
  salvarTempo();
}

function diminuirTempo() {
  if (minutos > 0) minutos--;
  atualizarDisplay();
  salvarTempo();
}

atualizarDisplay(); // inicializa