package com.example.Placar.Judo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
public class PlacarController {

    @GetMapping("/")
    public String index() {
        return "controle"; // Vai buscar em templates/controle.html
    }

    @ResponseBody
    @GetMapping("/placar")
    public Map<String, Integer> getPlacar() {
        Map<String, Integer> placar = new HashMap<>();
        placar.put("timeA", 2);
        placar.put("timeB", 1);
        return placar;
    }
}
