package com.example.Placar.Judo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacarJudoApplicationTests {

	@Test
	void contextLoads() {
	}

}
