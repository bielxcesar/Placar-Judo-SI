
setPlacar(getPlacar());
function getPlacar() {
  return JSON.parse(localStorage.getItem('placar')) || {
    ipponA: 0, wazariA: 0, yukoA: 0, shidoA: 0,
    ipponB: 0, wazariB: 0, yukoB: 0, shidoB: 0
  };
}

function setPlacar(placar) {
  localStorage.setItem('placar', JSON.stringify(placar));
  for (const tipo of ['ippon', 'wazari', 'yuko', 'shido']) {
    for (const lado of ['A', 'B']) {
      const id = `${tipo}${lado}`;
      const el = document.getElementById(id);
      if (el) {
        el.textContent = placar[id];
      }

      // Atualiza os cartões visuais de Shido
      if (tipo === 'shido') {
        atualizarCartoesShido(placar[id], lado);
      }
    }
  }
}
function houveIppon() {
  const placar = getPlacar();
  return placar.ipponA > 0 || placar.ipponB > 0;
}

function increment(tipo, lado) {
  const placar = getPlacar();
  placar[`${tipo}${lado}`]++;
  setPlacar(placar);
}

function decrement(tipo, lado) {
  const placar = getPlacar();
  placar[`${tipo}${lado}`] = Math.max(0, placar[`${tipo}${lado}`] - 1);
  setPlacar(placar);
}

function atualizarPlacar() {
  setPlacar(getPlacar());
}


function getPenalidades() {
  return JSON.parse(localStorage.getItem('penalidades')) || {
    A: 0, B: 0
  };
}

function setPenalidades(penalidades) {
  localStorage.setItem('penalidades', JSON.stringify(penalidades));
}

function atualizarPenalidade(time) {
  const penalidades = getPenalidades();
  const select = document.getElementById(`penalidade${time}`);
  penalidades[time] = parseInt(select.value);
  setPenalidades(penalidades);
}

// Inicialização
setPlacar(getPlacar());

const penalidadesIniciais = getPenalidades();
for (const time in penalidadesIniciais) {
  const select = document.getElementById(`penalidade${time}`);
  if (select) {
    select.value = penalidadesIniciais[time];
  }
}

let minutos = 0;
let segundos = 0;
let timerInterval;
let tempoSubindo = false;

function atualizarDisplay() {
  const m = String(minutos).padStart(2, '0');
  const s = String(segundos).padStart(2, '0');
  const prefixo = tempoSubindo ? '+' : '';
  document.getElementById('tempo').textContent = `${prefixo}${m}:${s}`;

  localStorage.setItem('tempo', JSON.stringify({
    minutos,
    segundos,
    golden: tempoSubindo
  }));
}
function atualizarCartoesShido(qtd, lado) {
  const container = document.getElementById(`cartoes-shido${lado}`);
  if (!container) return;

  container.innerHTML = ''; // Limpa os cartões anteriores

  const maxCartoes = Math.min(qtd, 3); // Limita a 3 cartões

  for (let i = 0; i < maxCartoes; i++) {
    const cartao = document.createElement('div');
    cartao.classList.add('cartao');
    container.appendChild(cartao);
  }
}

// Exemplo: atualiza com 2 shidos
atualizarCartoesShido(2);

function iniciarTimer() {
  clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      if (houveIppon()) {
        pausarTimer();
        alert("Ippon marcado! Tempo pausado."); // pode remover se quiser sem alerta
        return;
      }

      const goldenAtivo = document.getElementById('goldenScore').checked;

      if (!tempoSubindo) {
        if (minutos === 0 && segundos === 0) {
          if (goldenAtivo) {
            const continuarGolden = confirm("Deseja continuar com o Golden Score?");
            if (continuarGolden) {
              tempoSubindo = true;
              segundos = 1;
            } else {
              clearInterval(timerInterval);
              return;
            }
          } else {
            clearInterval(timerInterval);
            return;
          }
        } else {
          if (segundos === 0) {
            segundos = 59;
            minutos--;
          } else {
            segundos--;
          }
        }
      } else {
        segundos++;
        if (segundos === 60) {
          segundos = 0;
          minutos++;
        }
      }

      atualizarDisplay();
    }, 1000);
  }

function pausarTimer() {
  clearInterval(timerInterval);
}

function resetarTimer() {
  clearInterval(timerInterval);
  minutos = 0;
  segundos = 0;
  tempoSubindo = false;

  atualizarDisplay();
  resetarSaikomi(); // inclui o reset do Saikomi
}

function aumentarTempo() {
  minutos++;
  atualizarDisplay();
}

function diminuirTempo() {
  if (minutos > 0) {
    minutos--;
  }
  atualizarDisplay();
}
function setarQuatroMinutos() {
  minutos = 4;
  segundos = 0;
  tempoSubindo = false;
  atualizarDisplay();
}
let intervaloSaikomi; // variável global

function iniciarSaikomi(time) {
  clearInterval(intervaloSaikomi);
  let segundos = 0;

  intervaloSaikomi = setInterval(() => {
    segundos++;
    localStorage.setItem('saikomi', JSON.stringify({ time, segundos }));
    document.getElementById('saikomiTimer').textContent = `Saikomi: ${segundos}s`;

    // Se quiser limitar o tempo, por exemplo, parar em 20s:
    if (segundos >= 20) {
      clearInterval(intervaloSaikomi);
    }
  }, 1000);
}

function resetarSaikomi() {
  clearInterval(intervaloSaikomi); // agora funciona!
  localStorage.removeItem('saikomi');
  document.getElementById('saikomiTimer').textContent = 'Saikomi: 00s';
}

// 🌗 Alternância de tema escuro/claro
const body = document.body;
const toggleBtn = document.getElementById('toggleTheme');

function aplicarTema(tema) {
  if (tema === 'escuro') {
    body.classList.add('dark-mode');
    toggleBtn.textContent = '🌞 Modo Claro';
  } else {
    body.classList.remove('dark-mode');
    toggleBtn.textContent = '🌚 Modo Escuro';
  }
  localStorage.setItem('tema', tema);
}

// Aplica o tema salvo ao carregar
const temaSalvo = localStorage.getItem('tema') || 'claro';
aplicarTema(temaSalvo);

// Alterna o tema ao clicar no botão
toggleBtn.addEventListener('click', () => {
  const novoTema = body.classList.contains('dark-mode') ? 'claro' : 'escuro';
  aplicarTema(novoTema);
});