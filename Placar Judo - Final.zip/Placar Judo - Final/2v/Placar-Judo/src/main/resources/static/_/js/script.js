function getPlacar() {
  return JSON.parse(localStorage.getItem('placar')) || {
    timeA: 0, timeB: 0, timeC: 0, timeD: 0, timeE: 0, timeF: 0
  };
}

function setPlacar(placar) {
  localStorage.setItem('placar', JSON.stringify(placar));
  document.getElementById('scoreA').textContent = placar.timeA;
  document.getElementById('scoreB').textContent = placar.timeB;
  document.getElementById('scoreC').textContent = placar.timeC;
  document.getElementById('scoreD').textContent = placar.timeD;
  document.getElementById('scoreE').textContent = placar.timeE;
  document.getElementById('scoreF').textContent = placar.timeF;
}

function increment(time) {
  const placar = getPlacar();
  placar[`time${time}`]++;
  setPlacar(placar);
}

function decrement(time) {
  const placar = getPlacar();
  placar[`time${time}`] = Math.max(0, placar[`time${time}`] - 1);
  setPlacar(placar);
}

function getPenalidades() {
  return JSON.parse(localStorage.getItem('penalidades')) || {
    A: 0, B: 0
  };
}

function setPenalidades(penalidades) {
  localStorage.setItem('penalidades', JSON.stringify(penalidades));
}

function atualizarPenalidade(time) {
  const penalidades = getPenalidades();
  const select = document.getElementById(`penalidade${time}`);
  penalidades[time] = parseInt(select.value);
  setPenalidades(penalidades);
}

// Inicialização
setPlacar(getPlacar());

const penalidadesIniciais = getPenalidades();
for (const time in penalidadesIniciais) {
  const select = document.getElementById(`penalidade${time}`);
  if (select) {
    select.value = penalidadesIniciais[time];
  }
}

let minutos = 0;
let segundos = 0;
let timerInterval;
let tempoSubindo = false;

function atualizarDisplay() {
  const m = String(minutos).padStart(2, '0');
  const s = String(segundos).padStart(2, '0');
  const prefixo = tempoSubindo ? '+' : '';
  document.getElementById('tempo').textContent = `${prefixo}${m}:${s}`;

  localStorage.setItem('tempo', JSON.stringify({
    minutos,
    segundos,
    golden: tempoSubindo
  }));
}

function iniciarTimer() {
  clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    const goldenAtivo = document.getElementById('goldenScore').checked;

    if (!tempoSubindo) {
      if (minutos === 0 && segundos === 0) {
        if (goldenAtivo) {
          tempoSubindo = true;
          segundos = 1;
        } else {
          clearInterval(timerInterval);
          return;
        }
      } else {
        if (segundos === 0) {
          segundos = 59;
          minutos--;
        } else {
          segundos--;
        }
      }
    } else {
      segundos++;
      if (segundos === 60) {
        segundos = 0;
        minutos++;
      }
    }

    atualizarDisplay();
  }, 1000);
}

function pausarTimer() {
  clearInterval(timerInterval);
}

function resetarTimer() {
  clearInterval(timerInterval);
  minutos = 0;
  segundos = 0;
  tempoSubindo = false;
  atualizarDisplay();
}

function aumentarTempo() {
  minutos++;
  atualizarDisplay();
}

function diminuirTempo() {
  if (minutos > 0) {
    minutos--;
  }
  atualizarDisplay();
}
